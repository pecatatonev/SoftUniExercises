﻿namespace WidlFarm.Models.Interfaces
{
    public interface IFood
    {
        int Quantity { get; }
    }
}